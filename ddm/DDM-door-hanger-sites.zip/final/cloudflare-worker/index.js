// Doorstep secure relay — Cloudflare Worker
//
// GitHub Pages can only serve static files, so it can't hold API secrets.
// This Worker is the one place that holds them: it talks to Twenty CRM and
// PayPal on behalf of the static site, using secrets that never reach the
// browser.
//
// Endpoints:
//   POST /api/lead                 -> creates a Person + Company in Twenty CRM
//   POST /api/paypal/create-order  -> creates a PayPal order (price computed here, not trusted from the client)
//   POST /api/paypal/capture-order -> captures a PayPal order after buyer approval
//
// Deploy:
//   wrangler deploy
//
// Secrets (set once, never appear in code or wrangler.toml):
//   wrangler secret put TWENTY_API_KEY
//   wrangler secret put PAYPAL_CLIENT_ID
//   wrangler secret put PAYPAL_CLIENT_SECRET
//
// Vars (set in wrangler.toml, not secret):
//   ALLOWED_ORIGINS  comma-separated list, e.g.
//                    https://site-one.github.io,https://site-two.github.io
//   TWENTY_API_BASE  e.g. https://api.twenty.com  (Twenty Cloud)
//   PAYPAL_API_BASE  https://api-m.sandbox.paypal.com for testing,
//                    https://api-m.paypal.com for live
//
// ---------------------------------------------------------------------
// FIX (this version): findOrCreateCompany() and findOrCreatePerson() used
// to fall back to blindly trusting whatever record came back FIRST from
// the Twenty search call, even if it didn't actually match the submitted
// business name / email. If the /rest/companies or /rest/people filter
// call wasn't scoping results the way the code assumed (wrong field key,
// workspace-specific quirk, etc.), every single lead silently got attached
// to whatever record happened to sort first — which is exactly what was
// happening (every lead was landing on the same pre-existing company and
// contact, regardless of what was typed into the form).
//
// Both functions now REQUIRE an exact match against the submitted data
// before treating a search result as "existing." No exact match -> a new
// Company/Person is created instead, which is always the safe default.
// searchRes.ok is also checked now so a failed/unauthorized search call
// is surfaced as an error instead of silently behaving like "no results."
// ---------------------------------------------------------------------

// This MUST match the pricing logic in the website's own JavaScript.
// The client only ever sends radius/size/qty — never a dollar amount —
// so a tampered page can't change what gets charged.
const PRICE_PER_UNIT_PER_2000 = 550;
const SIZE_UNITS = { third: 1, half: 2, full: 3, both: 6 };
const SIZE_LABELS = { third: '1/3 page', half: 'Half page', full: 'Full page', both: 'Both sides' };

function computePrice(size, qty) {
  const units = SIZE_UNITS[size];
  if (!units || !qty || qty < 2000) return null;
  return Math.round(PRICE_PER_UNIT_PER_2000 * units * (qty / 2000) * 100) / 100;
}

// ---------- Doorhanger campaign object field mapping ----------
// Confirmed against a real record pulled from /rest/doorhangers on 2026-08-31.
// The object's real API name is "doorhangers" (not "campaigns" — that was a
// leftover object from earlier experimentation and is unused).
//
// Still to confirm: the exact Select option VALUES for adSize (e.g. is
// "1/3 page" stored as 'THIRD_PAGE', 'ONE_THIRD', etc?). Set the field by
// hand on a test record and re-check via the GET script to nail this down.
const DOORHANGER_OBJECT = 'doorhangers';
const CAMPAIGN_FIELDS = {
  name: 'name',
  adSize: 'adSize',
  quantity: 'qty',
  radius: 'radius',
  price: 'price',
  status: 'status',
  sourceSite: 'sourceSite',
  designNotes: 'designNotes',
  companyId: 'companyId',
  contactId: 'contactId',
  // Added so city/state/zip/category show up as their own tracked,
  // filterable fields on the Doorhanger record itself (not just buried
  // inside the linked Company's address). These four fields (City, State,
  // Zip code, Category) must exist on the "doorhangers" object in Twenty
  // first — Settings > Data model > Doorhangers > + Field — before this
  // will work. The API field key Twenty generates for each one depends on
  // exactly what you name the field there; the values below are the most
  // likely auto-generated keys (same camelCase pattern as the existing
  // fields above), but confirm/adjust them the same way adSize was
  // confirmed: submit one test lead, then GET the record back from
  // /rest/doorhangers and check the actual key names in the response.
  city: 'city',
  state: 'state',
  zip: 'zip',
  category: 'category',
};

// Confirmed against Twenty's actual validation error on 2026-08-31.
const SIZE_SELECT_VALUES = {
  third: 'OPT1_3_PAGE',
  half: 'HALF_PAGE',
  full: 'FULL_PAGE',
  both: 'BOTH_PAGES',
};

// Status is a Select field with (at least) two confirmed options: "new
// unpaid" and "new paid". Values below are best-guess API values based on
// Twenty's label->value convention (spaces->underscores, uppercase). If
// wrong, campaignError in the /api/lead response will say so — same pattern
// that caught the adSize mismatch earlier.
const CAMPAIGN_STATUS_NEW_UNPAID = 'NEW_UNPAID';
const CAMPAIGN_STATUS_NEW_PAID = 'NEW_PAID'; // not yet used — payment flow is on hold

// The Access-Control-Allow-Origin header can only ever echo back ONE origin
// per response — it can't just be the raw comma-separated list. So for
// multiple sites sharing this Worker, we check the request's actual Origin
// against the allow-list and reflect back only that one if it matches.
function resolveOrigin(request, env) {
  const list = (env.ALLOWED_ORIGINS || '*').split(',').map(o => o.trim());
  if (list.includes('*')) return '*';
  const requestOrigin = request.headers.get('Origin') || '';
  return list.includes(requestOrigin) ? requestOrigin : list[0];
}

function corsHeaders(request, env) {
  return {
    'Access-Control-Allow-Origin': resolveOrigin(request, env),
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    Vary: 'Origin',
  };
}

function json(data, status, request, env) {
  return new Response(JSON.stringify(data), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(request, env) },
  });
}

// ---------- Twenty CRM ----------
// Twenty auto-generates REST endpoints from your workspace's schema, so the
// exact response shape can vary a little between workspaces. Use your
// workspace's own API playground (Settings > API & Webhooks) to confirm the
// field names below match your setup, then adjust if needed.

async function twentyRequest(env, path, body) {
  const res = await fetch(`${env.TWENTY_API_BASE}/rest/${path}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.TWENTY_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Twenty ${path} failed: ${res.status} ${JSON.stringify(data)}`);
  return data;
}

// GET helper used by the search calls below. Unlike twentyRequest(), a
// failed search should not be silently treated as "zero results" — that
// was part of how a bad match could slip through unnoticed — so this
// throws on a non-OK response instead of swallowing it.
async function twentySearch(env, path) {
  const res = await fetch(`${env.TWENTY_API_BASE}/rest/${path}`, {
    headers: { Authorization: `Bearer ${env.TWENTY_API_KEY}` },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Twenty search ${path} failed: ${res.status} ${JSON.stringify(data)}`);
  return data;
}

async function findOrCreateCompany(env, lead) {
  // Search by name, but NEVER trust the result unless it's an exact match
  // on name (and, if we have a candidate with an address, the zip). If the
  // search call returns something unexpected (wrong field key, workspace
  // quirk, unfiltered fallback, etc.), an exact-match check is what stops
  // a new lead from silently attaching to an unrelated existing company.
  const searchData = await twentySearch(
    env,
    `companies?filter[name][eq]=${encodeURIComponent(lead.businessName)}`
  );
  const candidates = searchData?.data?.companies || searchData?.companies || [];

  const existing = candidates.find(c => {
    if (c?.name !== lead.businessName) return false;
    // If the candidate has a zip on file, it must match too (this is what
    // distinguishes two different businesses that happen to share a name,
    // common with franchises). If it has no zip on file yet, name equality
    // alone is fine.
    if (c?.address?.addressPostcode && lead.businessZip) {
      return c.address.addressPostcode === lead.businessZip;
    }
    return true;
  });
  if (existing) return existing.id;

  const companyPayload = {
    name: lead.businessName,
    address: {
      addressStreet1: lead.businessStreet,
      addressCity: lead.businessCity,
      addressState: lead.businessState,
      addressPostcode: lead.businessZip,
      addressCountry: 'United States',
    },
  };
  if (lead.businessWebsite) {
    // Twenty's website field is typically a composite "Link" object. If your
    // workspace uses a plain text field for this instead, adjust the shape
    // here to match (check Settings > API & Webhooks).
    companyPayload.domainName = {
      primaryLinkUrl: lead.businessWebsite,
      primaryLinkLabel: lead.businessWebsite,
    };
  }

  const created = await twentyRequest(env, 'companies', companyPayload);
  return created?.data?.createCompany?.id || created?.id;
}

// Short human-readable reference the customer can quote before payment,
// and that ties together the CRM note / PayPal order / support conversation
// even before a dedicated Campaign object exists in Twenty.
function makeReferenceId() {
  const stamp = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `DH-${stamp}-${rand}`;
}

// Twenty enforces unique emails on People, so a second campaign from the
// same contact (or a resubmitted form) must reuse the existing Person
// instead of trying to create a duplicate. Mirrors findOrCreateCompany —
// same exact-match requirement, same reasoning: never trust "first result"
// as a match.
async function findOrCreatePerson(env, lead, companyId, firstName, lastName, digitsOnly) {
  const searchData = await twentySearch(
    env,
    `people?filter[emails.primaryEmail][eq]=${encodeURIComponent(lead.email)}`
  );
  const candidates = searchData?.data?.people || searchData?.people || [];

  const existing = candidates.find(p => p?.emails?.primaryEmail === lead.email);
  if (existing) return existing.id;

  const created = await twentyRequest(env, 'people', {
    name: { firstName, lastName },
    emails: { primaryEmail: lead.email },
    phones: {
      primaryPhoneNumber: digitsOnly,
      primaryPhoneCountryCode: 'US',
      primaryPhoneCallingCode: '+1',
    },
    jobTitle: lead.jobTitle,
    companyId,
  });
  return created?.data?.createPerson?.id || created?.id;
}

// Creates a structured Campaign record — this is what makes ad size, qty,
// radius, and price actually queryable/filterable in Twenty, instead of
// living only as text inside a Note. Returns null (rather than throwing) if
// the Campaign object doesn't exist yet or field names don't match, so lead
// creation never breaks while this is being set up on the Twenty side.
async function createCampaign(env, lead, referenceId, companyId, personId) {
  const payload = {
    [CAMPAIGN_FIELDS.name]: referenceId,
    [CAMPAIGN_FIELDS.adSize]: SIZE_SELECT_VALUES[lead.size],
    [CAMPAIGN_FIELDS.quantity]: lead.qty,
    [CAMPAIGN_FIELDS.radius]: lead.radius,
    // Twenty's Currency fields are composite objects, not raw numbers.
    [CAMPAIGN_FIELDS.price]: {
      amountMicros: Math.round(lead.price * 1000000),
      currencyCode: 'USD',
    },
    [CAMPAIGN_FIELDS.status]: CAMPAIGN_STATUS_NEW_UNPAID,
    [CAMPAIGN_FIELDS.sourceSite]: lead.source || 'Unknown site',
    [CAMPAIGN_FIELDS.designNotes]: lead.designNotes || '',
    [CAMPAIGN_FIELDS.companyId]: companyId,
    [CAMPAIGN_FIELDS.contactId]: personId,
    // City/state/zip come from the business address already collected on
    // the form; category is which DDM trade site the lead came from
    // (e.g. "Roofing", "Plumbing") and is sent by the site automatically.
    [CAMPAIGN_FIELDS.city]: lead.businessCity || '',
    [CAMPAIGN_FIELDS.state]: lead.businessState || '',
    [CAMPAIGN_FIELDS.zip]: lead.businessZip || '',
    [CAMPAIGN_FIELDS.category]: lead.category || '',
  };

  try {
    const created = await twentyRequest(env, DOORHANGER_OBJECT, payload);
    return { id: created?.data?.createDoorhanger?.id || created?.id || null, error: null };
  } catch (err) {
    console.log('Campaign creation failed:', err.message);
    return { id: null, error: err.message };
  }
}

async function createLead(env, lead) {
  const referenceId = makeReferenceId();
  const companyId = await findOrCreateCompany(env, lead);

  const nameParts = (lead.fullName || '').trim().split(/\s+/);
  const firstName = nameParts[0] || lead.fullName;
  const lastName = nameParts.slice(1).join(' ');
  const digitsOnly = (lead.phone || '').replace(/\D/g, '');

  const personId = await findOrCreatePerson(env, lead, companyId, firstName, lastName, digitsOnly);

  const campaign = await createCampaign(env, lead, referenceId, companyId, personId);
  const campaignId = campaign.id;

  // Best-effort: attach a note with full campaign + geo + design context.
  // Kept as a redundant, always-readable record even after the Campaign
  // object exists — if your workspace uses different object/relation names
  // for notes, this step is skipped rather than failing the whole lead.
  try {
    const note = await twentyRequest(env, 'notes', {
      title: `Door hanger campaign — ${referenceId}`,
      body:
        `Reference: ${referenceId}\n` +
        `Submitted: ${new Date().toISOString()}\n` +
        `Source site: ${lead.source || 'Unknown site'}\n` +
        `Category: ${lead.category || 'Unknown'}\n` +
        `Payment status: New — unpaid\n` +
        `\n--- Campaign ---\n` +
        `Ad size: ${SIZE_LABELS[lead.size]}\n` +
        `Quantity: ${lead.qty}\n` +
        `Estimated total: $${lead.price}\n` +
        `\n--- Distribution area ---\n` +
        `Radius: ${lead.radius} miles\n` +
        `Center (business address): ${lead.businessStreet}, ${lead.businessCity}, ${lead.businessState} ${lead.businessZip}\n` +
        (lead.designNotes ? `\n--- Design notes ---\n${lead.designNotes}\n` : ''),
    });
    const noteId = note?.data?.createNote?.id || note?.id;
    if (noteId && personId) {
      await twentyRequest(env, 'noteTargets', { noteId, personId });
    }
  } catch (err) {
    console.log('Note attach skipped:', err.message);
  }

  return { personId, companyId, campaignId, campaignError: campaign.error, referenceId };
}

// ---------- PayPal ----------

async function paypalToken(env) {
  const creds = btoa(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_CLIENT_SECRET}`);
  const res = await fetch(`${env.PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${creds}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });
  const data = await res.json();
  if (!res.ok) throw new Error('PayPal auth failed: ' + JSON.stringify(data));
  return data.access_token;
}

// ---------- Router ----------

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders(request, env) });
    }

    const url = new URL(request.url);

    try {
      if (request.method === 'POST' && url.pathname === '/api/lead') {
        const body = await request.json();
        const price = computePrice(body.size, body.qty);
        if (!price) return json({ error: 'Invalid campaign details' }, 400, request, env);
        if (!body.email || !body.fullName || !body.businessName ||
            !body.businessStreet || !body.businessCity || !body.businessState || !body.businessZip) {
          return json({ error: 'Missing required fields' }, 400, request, env);
        }

        const result = await createLead(env, { ...body, price });
        return json({ ok: true, price, ...result }, 200, request, env);
      }

      if (request.method === 'POST' && url.pathname === '/api/paypal/create-order') {
        const body = await request.json();
        const price = computePrice(body.size, body.qty);
        if (!price) return json({ error: 'Invalid campaign details' }, 400, request, env);

        const token = await paypalToken(env);
        const orderRes = await fetch(`${env.PAYPAL_API_BASE}/v2/checkout/orders`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            intent: 'CAPTURE',
            purchase_units: [
              {
                description: `Doorstep campaign — ${SIZE_LABELS[body.size]}, ${body.qty} hangers, ${body.radius}mi radius (source: ${body.source || 'unknown'})`,
                amount: { currency_code: 'USD', value: price.toFixed(2) },
              },
            ],
          }),
        });
        const order = await orderRes.json();
        if (!orderRes.ok) return json({ error: order }, 500, request, env);
        return json({ id: order.id }, 200, request, env);
      }

      if (request.method === 'POST' && url.pathname === '/api/paypal/capture-order') {
        const body = await request.json();
        if (!body.orderID) return json({ error: 'Missing orderID' }, 400, request, env);

        const token = await paypalToken(env);
        const capRes = await fetch(`${env.PAYPAL_API_BASE}/v2/checkout/orders/${body.orderID}/capture`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        });
        const capture = await capRes.json();
        if (!capRes.ok) return json({ error: capture }, 500, request, env);
        return json(capture, 200, request, env);
      }

      return json({ error: 'Not found' }, 404, request, env);
    } catch (err) {
      return json({ error: err.message }, 500, request, env);
    }
  },
};
