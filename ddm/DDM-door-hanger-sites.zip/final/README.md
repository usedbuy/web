# Direct to Door Marketing (DDM) — 11 industry landing pages

This bundle contains 11 standalone websites, one per trade, each built from
the original door hanger builder/checkout page and rebranded to
**Direct to Door Marketing (DDM)**. Every page talks to the same Cloudflare
Worker (`cloudflare-worker/index.js`) that relays leads into Twenty CRM, so
all 11 sites are drop-in compatible with the existing backend.

## Folder structure

```
DDM-roofing/
  DDM-roofing.html
  images/
    logo.png          <- DDM brand mark (nav + footer)
    favicon.png        <- browser tab icon
    icon-roofing.png    <- icon used in the "why door hangers work" section
DDM-pressure-washing/
  DDM-pressure-washing.html
  images/...
DDM-landscaping/
DDM-hardscaping/
DDM-house-cleaning/
DDM-heating-cooling/
DDM-junk-removal/
DDM-fencing/
DDM-window-repair/
DDM-plumbing/
DDM-remodeling/

cloudflare-worker/
  index.js            <- unchanged relay Worker, shared by all 11 sites
```

Each site is fully self-contained: open `DDM-<industry>/DDM-<industry>.html`
directly in a browser, or upload the whole `DDM-<industry>/` folder
(including its `images/` folder) to whatever static host you use per site
(GitHub Pages, Cloudflare Pages, etc.) — keep the HTML file and the
`images/` folder in the same directory.

## What changed per site

Each page keeps the exact same builder/pricing/checkout mechanics as the
original file — same form field IDs, same pricing math
(`550 * unitsForSize * (qty / 2000)` plus the same extras), and the same
JSON payload shape sent to `/api/lead`. Only the following are customized
per industry:

- Page `<title>` and meta description
- Hero eyebrow, headline, and lead paragraph
- A new "Why door hangers work for **[trade]**" section (3 benefit cards)
  with an industry icon, inserted between the hero and the results section
- Sample business name shown in the rotating ad-mockup slideshow
- The business-name field's placeholder text
- Brand name/logo everywhere ("Porchlight" / "Door hanger marketing" →
  "Direct to Door Marketing" / "DDM"), including the nav, footer, favicon,
  and the small brand label printed on the interactive door-hanger card
- Contact email → `hello@directtodoormarketing.com`
- The `SOURCE` constant in each page's script, pre-filled as
  `REPLACE-WITH-DDM-<INDUSTRY>-ACTUAL-DOMAIN` — **you must replace this**
  with that site's real published domain before going live, exactly as the
  original file required. This value is what tags each CRM lead with which
  site it came from.

Everything else — the campaign builder, live pricing, 3D hanger preview,
FAQ, and PayPal/CRM integration hooks — is untouched from the original file.

## Connecting to the Cloudflare Worker / Twenty CRM

1. Deploy `cloudflare-worker/index.js` with `wrangler deploy` (or update
   your existing deployment — the code is unchanged except for a comment).
2. In the Worker's `ALLOWED_ORIGINS` variable, add the real published origin
   for **every** one of the 11 sites, comma-separated, e.g.:
   `https://ddm-roofing.pages.dev,https://ddm-plumbing.pages.dev,...`
3. In each site's HTML, replace the `SOURCE` placeholder
   (`REPLACE-WITH-DDM-<INDUSTRY>-ACTUAL-DOMAIN`) with that same real domain.
4. `WORKER_URL` in each site already points at the existing Worker endpoint
   used in the original file — update it in all 11 files if you deploy the
   Worker to a new URL.
5. No Twenty CRM field mapping changes are needed — all 11 sites send the
   identical payload shape (`fullName`, `email`, `phone`, `jobTitle`,
   `businessName`, `businessWebsite`, `businessStreet`, `businessCity`,
   `businessState`, `businessZip`, `designNotes`, `qrForwardUrl`, `source`,
   `radius`, `size`, `qty`, `extras`) that the Worker already expects.

## Images

Each site's `images/` folder currently holds a generated DDM logo, favicon,
and one industry icon. Swap in real photography (job photos, before/afters)
by adding files to that same folder and pointing an `<img>` tag at
`images/your-file.png` — the existing hero/mockup and 3D door-hanger visuals
are inline SVG (needed for their CSS animations) and are left as-is, exactly
as flagged in the original file's own placeholder comments.
